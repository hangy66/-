##以下为实验基础要求：
1.增加时间戳显示，参考了https://wenku.csdn.net/answer/eddd950f0bbb434cb5c030c618774aa2
https://blog.csdn.net/VLOKL/article/details/134476422
//在noteslist_item.xml中，添加一个TextView，并将布局改为LinearLayout
<TextView
android:id="@android:id/text2"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:gravity="center_vertical"
android:paddingLeft="5dp"
android:singleLine="true"
android:textAppearance="?android:attr/textAppearanceLarge"
android:textSize="15dp" />

//在NoteList类中的PROJECTION添加MODIFICATION_DATE变量
private static final String[] PROJECTION = new String[] {
NotePad.Notes._ID,
NotePad.Notes.COLUMN_NAME_TITLE,
NotePad.Notes.COLUMN_NAME_MODIFICATION_DATE,};


//增加相关的参数
String[] dataColumns = { NotePad.Notes.COLUMN_NAME_TITLE,
NotePad.Notes.COLUMN_NAME_MODIFICATION_DATE //增加时间参数
} ;

    // The view IDs that will display the cursor columns, initialized to the TextView in
    // noteslist_item.xml
    int[] viewIDs = { android.R.id.text1 ,android.R.id.text2};

    // Creates the backing adapter for the ListView.
     SimpleCursorAdapter adapter
        = new SimpleCursorAdapter(
              this,                             // The Context for the ListView
              R.layout.noteslist_item,          // Points to the XML for a list item
              cursor,                           // The cursor to get items from
              dataColumns,
              viewIDs
      );


//在NoteEditor里的updateNote()方法中添加
ContentValues values = new ContentValues();
Long now = Long.valueOf(System.currentTimeMillis());
SimpleDateFormat sf = new SimpleDateFormat("yy/MM/dd HH:mm");
Date d = new Date(now);
String format = sf.format(d);
values.put(NotePad.Notes.COLUMN_NAME_MODIFICATION_DATE, format);

2.添加笔记查询功能
//在list_options_menu.xml文件下加一个搜索图标的item
<item
android:id="@+id/menu_search"
android:icon="@android:drawable/ic_menu_search"
android:showAsAction="always"
android:title="@string/menu_search"
android:alphabeticShortcut='s'/>


//在NoteList中找到onOptionsItemSelected()方法，在switch中添加搜索的case语句:
case R.id.menu_search:
Intent intent = new Intent();
intent.setClass(NotesList.this,NoteSearch.class);
NotesList.this.startActivity(intent);
return true;


//在layout中新建布局文件note_search.xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
android:layout_width="match_parent"
android:layout_height="match_parent"
android:orientation="vertical">

//建立NoteSearch类，实现SearchView.OnQueryTextListener接口
public class NoteSearch extends Activity implements SearchView.OnQueryTextListener {
ListView listView;
SQLiteDatabase sqLiteDatabase;
/**
* The columns needed by the cursor adapter
*/
private static final String[] PROJECTION = new String[]{
NotePad.Notes._ID, // 0
NotePad.Notes.COLUMN_NAME_TITLE, // 1
NotePad.Notes.COLUMN_NAME_MODIFICATION_DATE//时间
};

public boolean onQueryTextSubmit(String query) {
Toast.makeText(this, "您选择的是："+query, Toast.LENGTH_SHORT).show();
return false;
}

@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.note_search);
SearchView searchView = findViewById(R.id.search_view);
Intent intent = getIntent();
if (intent.getData() == null) {
intent.setData(NotePad.Notes.CONTENT_URI);
}
listView = findViewById(R.id.list_view);
sqLiteDatabase = new NotePadProvider.DatabaseHelper(this).getReadableDatabase();
//设置该SearchView显示搜索按钮
searchView.setSubmitButtonEnabled(true);

//设置该SearchView内默认显示的提示文本
searchView.setQueryHint("查找");
searchView.setOnQueryTextListener(this);
}
public boolean onQueryTextChange(String string) {
String selection1 = NotePad.Notes.COLUMN_NAME_TITLE+" like ? or "+NotePad.Notes.COLUMN_NAME_NOTE+" like ?";
String[] selection2 = {"%"+string+"%","%"+string+"%"};
Cursor cursor = sqLiteDatabase.query(
NotePad.Notes.TABLE_NAME,
PROJECTION, // The columns to return from the query
selection1, // The columns for the where clause
selection2, // The values for the where clause
null,          // don't group the rows
null,          // don't filter by row groups
NotePad.Notes.DEFAULT_SORT_ORDER // The sort order
);
String[] dataColumns = {
NotePad.Notes.COLUMN_NAME_TITLE,
NotePad.Notes.COLUMN_NAME_MODIFICATION_DATE
} ;
// The view IDs that will display the cursor columns, initialized to the TextView in
// noteslist_item.xml
int[] viewIDs = {
android.R.id.text1,
android.R.id.text2
};
// Creates the backing adapter for the ListView.
SimpleCursorAdapter adapter
= new SimpleCursorAdapter(
this,                             // The Context for the ListView
R.layout.noteslist_item,         // Points to the XML for a list item
cursor,                           // The cursor to get items from
dataColumns,
viewIDs
);
// Sets the ListView's adapter to be the cursor adapter that was just created.
listView.setAdapter(adapter);
return true;
}}
这里个人查阅资料和考量之下选择了分类、UI美化的扩展内容
UI美化（主题设定、更改记事本背景、优化编辑器等）在查阅资料后制作失败，以下是失败过程
主题设定：在styles.xml中定义不同的主题样式。
更改记事本背景：在activity_main.xml中使用ImageView作为背景。
优化编辑器：使用EditText的自定义属性来优化输入体验。
分类时新建一个xml文件中添加一个下拉菜单（Spinner）用于选择分类。
   <?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:orientation="vertical"
android:gravity="center_vertical">

    <Spinner
        android:id="@+id/spinner2"
        android:layout_width="match_parent"
        android:layout_height="50dp"
        android:background="#EDEDED" />

</LinearLayout>
处理分类选择逻辑，并在搜索时考虑分类过滤。
